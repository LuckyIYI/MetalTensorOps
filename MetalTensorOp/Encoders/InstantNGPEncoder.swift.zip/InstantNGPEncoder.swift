import Metal
import Foundation
import QuartzCore

enum InstantNGPError: Error {
    case failedToCreateBuffer
    case failedToAllocateHashTable
    case invalidConfiguration
    case failedToCreatePipeline
}

struct InstantNGPConfig {
    static let numLevels = 16
    static let featuresPerLevel = 2
    static let log2HashmapSize = 19
    static let baseResolution = 16
    static let maxResolution = 2048
    static let totalFeatures = numLevels * featuresPerLevel

    static let mlpHiddenWidth = 64
    static let mlpOutputDim = 3
    static let mlpNumLayers = 2

    static let batchSize = 64
}

final class InstantNGPEncoder: ComputeEncoder {
    private let device: MTLDevice
    private let queue: MTL4CommandQueue

    private let renderPipelineState: MTLComputePipelineState
    private let inferencePipelineState: MTLComputePipelineState
    private let inferenceDebugPipelineState: MTLComputePipelineState

    private let renderArgumentTable: any MTL4ArgumentTable
    private let inferenceArgumentTable: any MTL4ArgumentTable
    private let inferenceDebugArgumentTable: any MTL4ArgumentTable

    private let renderResidencySet: MTLResidencySet
    private let inferenceResidencySet: MTLResidencySet

    private let hashTable: MTLBuffer
    private let layer1Weights: MTLTensor
    private let layer1Bias: MTLTensor
    private let layer2Weights: MTLTensor
    private let layer2Bias: MTLTensor

    private let layer1WeightsBuffer: MTLBuffer
    private let layer1BiasBuffer: MTLBuffer
    private let layer2WeightsBuffer: MTLBuffer
    private let layer2BiasBuffer: MTLBuffer

    private let timeBuffer: MTLBuffer
    private let numPositionsBuffer: MTLBuffer

    struct WeightBuffers {
        let layer1Weights: MTLBuffer
        let layer1Bias: MTLBuffer
        let layer2Weights: MTLBuffer
        let layer2Bias: MTLBuffer
        let layer1StrideDim0: Int
        let layer2StrideDim0: Int
    }

    var weightBuffers: WeightBuffers {
        WeightBuffers(
            layer1Weights: layer1WeightsBuffer,
            layer1Bias: layer1BiasBuffer,
            layer2Weights: layer2WeightsBuffer,
            layer2Bias: layer2BiasBuffer,
            layer1StrideDim0: InstantNGPConfig.totalFeatures,
            layer2StrideDim0: InstantNGPConfig.mlpHiddenWidth
        )
    }

    var hashTableBuffer: MTLBuffer { hashTable }

    init(device: MTLDevice, library: MTLLibrary, compiler: MTL4Compiler, queue: MTL4CommandQueue) throws {
        self.device = device
        self.queue = queue

        let config = InstantNGPConfig.self

        // Hash table
        let hashTableSize = (1 << config.log2HashmapSize) * config.numLevels * config.featuresPerLevel * MemoryLayout<Float16>.stride
        guard let hashTable = device.makeBuffer(length: hashTableSize, options: .storageModeShared) else {
            throw InstantNGPError.failedToAllocateHashTable
        }
        self.hashTable = hashTable

        let hashPtr = hashTable.contents().bindMemory(to: Float16.self, capacity: hashTableSize / MemoryLayout<Float16>.stride)
        let scale = Float16(1.0 / sqrt(Float(config.featuresPerLevel)))
        for i in 0..<(hashTableSize / MemoryLayout<Float16>.stride) {
            hashPtr[i] = Float16(Float.random(in: -1...1) * Float(scale))
        }

        // Layer 1 weights
        let layer1WeightsSize = config.totalFeatures * config.mlpHiddenWidth
        guard let layer1WeightsBuffer = device.makeBuffer(length: layer1WeightsSize * MemoryLayout<Float16>.stride, options: .storageModeShared) else {
            throw InstantNGPError.failedToCreateBuffer
        }
        let layer1WPtr = layer1WeightsBuffer.contents().bindMemory(to: Float16.self, capacity: layer1WeightsSize)
        let layer1Scale = Float16(sqrt(2.0 / Float(config.totalFeatures)))
        for i in 0..<layer1WeightsSize {
            layer1WPtr[i] = Float16(Float.random(in: -1...1) * Float(layer1Scale))
        }
        let layer1WeightsDesc = MTLTensorDescriptor()
        layer1WeightsDesc.dimensions = MTLTensorExtents([config.mlpHiddenWidth, config.totalFeatures])!
        layer1WeightsDesc.strides = MTLTensorExtents([1, config.mlpHiddenWidth])!
        layer1WeightsDesc.usage = .compute
        layer1WeightsDesc.dataType = .float16
        self.layer1WeightsBuffer = layer1WeightsBuffer
        self.layer1Weights = try layer1WeightsBuffer.makeTensor(descriptor: layer1WeightsDesc, offset: 0)

        // Layer 1 bias
        guard let layer1BiasBuffer = device.makeBuffer(length: config.mlpHiddenWidth * MemoryLayout<Float16>.stride, options: .storageModeShared) else {
            throw InstantNGPError.failedToCreateBuffer
        }
        layer1BiasBuffer.contents().initializeMemory(as: Float16.self, repeating: 0, count: config.mlpHiddenWidth)
        let layer1BiasDesc = MTLTensorDescriptor()
        layer1BiasDesc.dimensions = MTLTensorExtents([config.mlpHiddenWidth])!
        layer1BiasDesc.strides = MTLTensorExtents([1])!
        layer1BiasDesc.usage = .compute
        layer1BiasDesc.dataType = .float16
        self.layer1BiasBuffer = layer1BiasBuffer
        self.layer1Bias = try layer1BiasBuffer.makeTensor(descriptor: layer1BiasDesc, offset: 0)

        // Layer 2 weights
        let layer2WeightsSize = config.mlpHiddenWidth * config.mlpOutputDim
        guard let layer2WeightsBuffer = device.makeBuffer(length: layer2WeightsSize * MemoryLayout<Float16>.stride, options: .storageModeShared) else {
            throw InstantNGPError.failedToCreateBuffer
        }
        let layer2WPtr = layer2WeightsBuffer.contents().bindMemory(to: Float16.self, capacity: layer2WeightsSize)
        let layer2Scale = Float16(sqrt(2.0 / Float(config.mlpHiddenWidth)))
        for i in 0..<layer2WeightsSize {
            layer2WPtr[i] = Float16(Float.random(in: -1...1) * Float(layer2Scale))
        }
        let layer2WeightsDesc = MTLTensorDescriptor()
        layer2WeightsDesc.dimensions = MTLTensorExtents([config.mlpOutputDim, config.mlpHiddenWidth])!
        layer2WeightsDesc.strides = MTLTensorExtents([1, config.mlpOutputDim])!
        layer2WeightsDesc.usage = .compute
        layer2WeightsDesc.dataType = .float16
        self.layer2WeightsBuffer = layer2WeightsBuffer
        self.layer2Weights = try layer2WeightsBuffer.makeTensor(descriptor: layer2WeightsDesc, offset: 0)

        // Layer 2 bias
        guard let layer2BiasBuffer = device.makeBuffer(length: config.mlpOutputDim * MemoryLayout<Float16>.stride, options: .storageModeShared) else {
            throw InstantNGPError.failedToCreateBuffer
        }
        layer2BiasBuffer.contents().initializeMemory(as: Float16.self, repeating: 0, count: config.mlpOutputDim)
        let layer2BiasDesc = MTLTensorDescriptor()
        layer2BiasDesc.dimensions = MTLTensorExtents([config.mlpOutputDim])!
        layer2BiasDesc.strides = MTLTensorExtents([1])!
        layer2BiasDesc.usage = .compute
        layer2BiasDesc.dataType = .float16
        self.layer2BiasBuffer = layer2BiasBuffer
        self.layer2Bias = try layer2BiasBuffer.makeTensor(descriptor: layer2BiasDesc, offset: 0)

        // Time + num positions buffers
        guard let timeBuffer = device.makeBuffer(length: MemoryLayout<Float>.stride, options: .storageModeShared) else {
            throw InstantNGPError.failedToCreateBuffer
        }
        self.timeBuffer = timeBuffer

        guard let numPositionsBuffer = device.makeBuffer(length: MemoryLayout<UInt32>.stride, options: .storageModeShared) else {
            throw InstantNGPError.failedToCreateBuffer
        }
        self.numPositionsBuffer = numPositionsBuffer

        // Render pipeline
        let renderFn = MTL4LibraryFunctionDescriptor()
        renderFn.name = "instantNGPRender"
        renderFn.library = library
        let renderDesc = MTL4ComputePipelineDescriptor()
        renderDesc.computeFunctionDescriptor = renderFn
        self.renderPipelineState = try compiler.makeComputePipelineState(descriptor: renderDesc)

        // Inference pipeline
        let inferenceFn = MTL4LibraryFunctionDescriptor()
        inferenceFn.name = "instantNGPInference"
        inferenceFn.library = library
        let inferenceDesc = MTL4ComputePipelineDescriptor()
        inferenceDesc.computeFunctionDescriptor = inferenceFn
        self.inferencePipelineState = try compiler.makeComputePipelineState(descriptor: inferenceDesc)

        // Inference debug pipeline
        let debugFn = MTL4LibraryFunctionDescriptor()
        debugFn.name = "instantNGPInferenceDebug"
        debugFn.library = library
        let debugDesc = MTL4ComputePipelineDescriptor()
        debugDesc.computeFunctionDescriptor = debugFn
        self.inferenceDebugPipelineState = try compiler.makeComputePipelineState(descriptor: debugDesc)

        // Argument tables
        let renderTableDesc = MTL4ArgumentTableDescriptor()
        renderTableDesc.maxTextureBindCount = 1
        renderTableDesc.maxBufferBindCount = 6
        self.renderArgumentTable = try device.makeArgumentTable(descriptor: renderTableDesc)
        renderArgumentTable.setResource(layer1Weights.gpuResourceID, bufferIndex: 0)
        renderArgumentTable.setResource(layer1Bias.gpuResourceID, bufferIndex: 1)
        renderArgumentTable.setResource(layer2Weights.gpuResourceID, bufferIndex: 2)
        renderArgumentTable.setResource(layer2Bias.gpuResourceID, bufferIndex: 3)
        renderArgumentTable.setAddress(hashTable.gpuAddress, index: 4)
        renderArgumentTable.setAddress(timeBuffer.gpuAddress, index: 5)

        let inferenceTableDesc = MTL4ArgumentTableDescriptor()
        inferenceTableDesc.maxBufferBindCount = 8
        self.inferenceArgumentTable = try device.makeArgumentTable(descriptor: inferenceTableDesc)
        inferenceArgumentTable.setResource(layer1Weights.gpuResourceID, bufferIndex: 0)
        inferenceArgumentTable.setResource(layer1Bias.gpuResourceID, bufferIndex: 1)
        inferenceArgumentTable.setResource(layer2Weights.gpuResourceID, bufferIndex: 2)
        inferenceArgumentTable.setResource(layer2Bias.gpuResourceID, bufferIndex: 3)
        inferenceArgumentTable.setAddress(hashTable.gpuAddress, index: 4)
        inferenceArgumentTable.setAddress(numPositionsBuffer.gpuAddress, index: 7)

        let debugTableDesc = MTL4ArgumentTableDescriptor()
        debugTableDesc.maxBufferBindCount = 11
        self.inferenceDebugArgumentTable = try device.makeArgumentTable(descriptor: debugTableDesc)
        inferenceDebugArgumentTable.setResource(layer1Weights.gpuResourceID, bufferIndex: 0)
        inferenceDebugArgumentTable.setResource(layer1Bias.gpuResourceID, bufferIndex: 1)
        inferenceDebugArgumentTable.setResource(layer2Weights.gpuResourceID, bufferIndex: 2)
        inferenceDebugArgumentTable.setResource(layer2Bias.gpuResourceID, bufferIndex: 3)
        inferenceDebugArgumentTable.setAddress(hashTable.gpuAddress, index: 4)
        inferenceDebugArgumentTable.setAddress(numPositionsBuffer.gpuAddress, index: 7)

        // Residency sets
        let renderResidency = try device.makeResidencySet(descriptor: .init())
        queue.addResidencySet(renderResidency)
        renderResidency.addAllocation(hashTable)
        renderResidency.addAllocation(timeBuffer)
        renderResidency.addAllocation(layer1Weights)
        renderResidency.addAllocation(layer1Bias)
        renderResidency.addAllocation(layer2Weights)
        renderResidency.addAllocation(layer2Bias)
        renderResidency.addAllocation(layer1WeightsBuffer)
        renderResidency.addAllocation(layer1BiasBuffer)
        renderResidency.addAllocation(layer2WeightsBuffer)
        renderResidency.addAllocation(layer2BiasBuffer)
        renderResidency.commit()
        self.renderResidencySet = renderResidency

        let inferenceResidency = try device.makeResidencySet(descriptor: .init())
        queue.addResidencySet(inferenceResidency)
        inferenceResidency.addAllocation(hashTable)
        inferenceResidency.addAllocation(layer1Weights)
        inferenceResidency.addAllocation(layer1Bias)
        inferenceResidency.addAllocation(layer2Weights)
        inferenceResidency.addAllocation(layer2Bias)
        inferenceResidency.addAllocation(layer1WeightsBuffer)
        inferenceResidency.addAllocation(layer1BiasBuffer)
        inferenceResidency.addAllocation(layer2WeightsBuffer)
        inferenceResidency.addAllocation(layer2BiasBuffer)
        inferenceResidency.addAllocation(numPositionsBuffer)
        inferenceResidency.commit()
        self.inferenceResidencySet = inferenceResidency
    }

    func encode(drawableTexture: MTLTexture, commandBuffer: MTL4CommandBuffer) {
        var t = Float(CACurrentMediaTime())
        memcpy(timeBuffer.contents(), &t, MemoryLayout<Float>.stride)

        guard let encoder = commandBuffer.makeComputeCommandEncoder() else { return }
        commandBuffer.useResidencySet(renderResidencySet)
        encoder.setComputePipelineState(renderPipelineState)
        encoder.setArgumentTable(renderArgumentTable)
        renderArgumentTable.setTexture(drawableTexture.gpuResourceID, index: 0)

        let tileWidth = 8
        let tileHeight = 8
        let threadsPerThreadgroup = MTLSize(width: renderPipelineState.threadExecutionWidth * 4, height: 1, depth: 1)
        let threadgroupsPerGrid = MTLSize(
            width: (drawableTexture.width + tileWidth - 1) / tileWidth,
            height: (drawableTexture.height + tileHeight - 1) / tileHeight,
            depth: 1
        )
        encoder.dispatchThreadgroups(
            threadgroupsPerGrid: threadgroupsPerGrid,
            threadsPerThreadgroup: threadsPerThreadgroup
        )
        encoder.endEncoding()
    }

    func encodeInference(
        positions: MTLTensor,
        outputs: MTLTensor,
        numPositions: UInt32,
        commandBuffer: MTL4CommandBuffer
    ) {
        guard let encoder = commandBuffer.makeComputeCommandEncoder() else { return }
        commandBuffer.useResidencySet(inferenceResidencySet)
        encoder.setComputePipelineState(inferencePipelineState)
        encoder.setArgumentTable(inferenceArgumentTable)
        inferenceArgumentTable.setResource(positions.gpuResourceID, bufferIndex: 5)
        inferenceArgumentTable.setResource(outputs.gpuResourceID, bufferIndex: 6)
        var count = numPositions
        memcpy(numPositionsBuffer.contents(), &count, MemoryLayout<UInt32>.stride)

        let threadsPerThreadgroup = MTLSize(width: inferencePipelineState.threadExecutionWidth * 4, height: 1, depth: 1)
        let numBatches = (Int(numPositions) + InstantNGPConfig.batchSize - 1) / InstantNGPConfig.batchSize
        let threadgroupsPerGrid = MTLSize(width: 1, height: numBatches, depth: 1)
        encoder.dispatchThreadgroups(
            threadgroupsPerGrid: threadgroupsPerGrid,
            threadsPerThreadgroup: threadsPerThreadgroup
        )
        encoder.endEncoding()
    }

    func encodeInferenceDebug(
        positions: MTLTensor,
        outputs: MTLTensor,
        numPositions: UInt32,
        encodedDebug: MTLTensor,
        hiddenDebug: MTLTensor,
        outputDebug: MTLTensor,
        commandBuffer: MTL4CommandBuffer
    ) {
        guard let encoder = commandBuffer.makeComputeCommandEncoder() else { return }
        commandBuffer.useResidencySet(inferenceResidencySet)
        encoder.setComputePipelineState(inferenceDebugPipelineState)
        encoder.setArgumentTable(inferenceDebugArgumentTable)
        inferenceDebugArgumentTable.setResource(positions.gpuResourceID, bufferIndex: 5)
        inferenceDebugArgumentTable.setResource(outputs.gpuResourceID, bufferIndex: 6)
        inferenceDebugArgumentTable.setResource(encodedDebug.gpuResourceID, bufferIndex: 8)
        inferenceDebugArgumentTable.setResource(hiddenDebug.gpuResourceID, bufferIndex: 9)
        inferenceDebugArgumentTable.setResource(outputDebug.gpuResourceID, bufferIndex: 10)
        var count = numPositions
        memcpy(numPositionsBuffer.contents(), &count, MemoryLayout<UInt32>.stride)

        let threadsPerThreadgroup = MTLSize(width: inferenceDebugPipelineState.threadExecutionWidth * 4, height: 1, depth: 1)
        let numBatches = (Int(numPositions) + InstantNGPConfig.batchSize - 1) / InstantNGPConfig.batchSize
        let threadgroupsPerGrid = MTLSize(width: 1, height: numBatches, depth: 1)
        encoder.dispatchThreadgroups(
            threadgroupsPerGrid: threadgroupsPerGrid,
            threadsPerThreadgroup: threadsPerThreadgroup
        )
        encoder.endEncoding()
    }
}
